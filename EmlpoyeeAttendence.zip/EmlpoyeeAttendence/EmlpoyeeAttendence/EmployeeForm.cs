﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace EmlpoyeeAttendence
{
    public partial class EmployeeForm : Form
    {
        private string username; 
        private Database db = new Database();
        private bool checkedIn = false; private DateTime checkInTime;
        public EmployeeForm(string username)
        {
            InitializeComponent();
            this.username = username;
            employeeName.Text = username;
        }

        private void btnCheckIn_Click(object sender, EventArgs e)
        {
            DateTime now = DateTime.Now;
            checkInTime = now;
            if (now.TimeOfDay > new TimeSpan(17, 0, 0)) // After 5 PM
            {
                MessageBox.Show("It's too late to check in. Try tomorrow or ask admin for attendance.");
            }
            if (now.TimeOfDay > new TimeSpan(8, 0, 0)) // After 8 AM
            { 
                db.IncrementAttendance(username, "late"); 
                MessageBox.Show("You are marked as late.");
            } 
            else 
            { 
                MessageBox.Show("Check-in successful.");
            }
            checkedIn = true;
        }

        private void btnCheckOut_Click(object sender, EventArgs e)
        {
            if (!checkedIn)
            {
                MessageBox.Show("You need to check in first.");
            }
            DateTime now = DateTime.Now;
            if (now.TimeOfDay < new TimeSpan(17, 0, 0)) // Before 5 PM
            {
                db.IncrementAttendance(username, "early_leave");
                MessageBox.Show("You are marked for early leave.");
            }
            else if (checkInTime.TimeOfDay <= new TimeSpan(8, 0, 0) && now.TimeOfDay >= new TimeSpan(17, 0, 0)) 
            {
                db.IncrementAttendance(username, "ontime"); MessageBox.Show("You have checked out on time."); 
            }
            else
            {
                MessageBox.Show("Check-out successfull.");
            }
            
        }

        private void btnCheckAttn_Click(object sender, EventArgs e)
        {
            DataTable attendanceTable = db.GetAllAttendance();
            var employeeAttendance = attendanceTable.Select($"username = '{username}'");
            if (employeeAttendance.Length > 0)
            {
                DataTable employeeAttendanceTable = employeeAttendance.CopyToDataTable();
                dataGridView2.DataSource = employeeAttendanceTable;

            }
            else 
            {
                MessageBox.Show("No attendance records found for the specified user.");
            }
        }
    }
}
