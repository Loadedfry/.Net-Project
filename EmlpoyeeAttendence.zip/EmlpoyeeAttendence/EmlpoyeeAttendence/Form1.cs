﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using MySql.Data.MySqlClient;


namespace EmlpoyeeAttendence
{
    public partial class Form1 : Form
    {
        

        public Form1()
        {
            InitializeComponent();
        }

        private void btnLogin_Click(object sender, EventArgs e)
        {
            string username = txtUsername.Text;
            string password = txtPassword.Text;

            Database db = new Database();
            string role;
            if (db.Login(username, password, out role))
            { 
                if (role == "admin")
                {
                    AdminForm adminForm = new AdminForm();
                    adminForm.Show();
                }
                else if (role == "employee")
                {
                    EmployeeForm employeeForm = new EmployeeForm(username);
                    employeeForm.Show();
                }
                this.Hide();
            }

            else
            {
                MessageBox.Show("Invalid username or password");
            }
            

        }
    }
}
