﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace EmlpoyeeAttendence
{
    public partial class AdminForm : Form
    {
        private Database db = new Database();
        public AdminForm()
        {
            InitializeComponent();
            
        }
        private void MyForm_Load(object sender, EventArgs e) 
        {
            LoadAttendanceRecords(); 
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void btnEmpAdd_Click(object sender, EventArgs e)
        {
            string username = txtAddEmpUserName.Text;
            string password = txtAddEmpPassword.Text;

            if (string.IsNullOrEmpty(username) || string.IsNullOrEmpty(password))
            {
                MessageBox.Show("Username and password cannot be empty.");
                return;
            }
            if (db.AddEmployee(username, password))
            {
                MessageBox.Show("Employee added successfully.");
                txtAddEmpUserName.Clear();
                txtAddEmpPassword.Clear();
            }
            else
            {
                MessageBox.Show("Failed to add employee.");
                txtAddEmpUserName.Clear();
                txtAddEmpPassword.Clear();
            }
        }

        private void btnEmpDel_Click(object sender, EventArgs e)
        {
            string username = txtAddEmpUserName.Text;
            string password = txtAddEmpPassword.Text;

            if (string.IsNullOrEmpty(username) || string.IsNullOrEmpty(password))
            {
                MessageBox.Show("Username and password cannot be empty.");
                return;
            }
            if (db.DeleteEmployee(username, password))
            {
                MessageBox.Show("Employee added successfully.");
                txtAddEmpUserName.Clear();
                txtAddEmpPassword.Clear();
            }
            else
            {
                MessageBox.Show("Failed to add employee.");
                txtAddEmpUserName.Clear();
                txtAddEmpPassword.Clear();
            }
        }

        private void btnAttnDel_Click(object sender, EventArgs e)
        {
            string username = txtEmpAttnUsername.Text;
            string status = "";
            foreach (string s in checkedListBox1.CheckedItems)
            {
                if (s == "Late")
                {
                    status = "late";
                }
                else if (s == "Early Leave")
                {
                    status = "early_leave";
                }
                else if (s == "Absent")
                {
                    status = "absent";
                }

            }
            if (db.DeleteAttendance(username, status))
            {
                MessageBox.Show("Delete attendace successfully");
                checkedListBox1.ClearSelected();
                txtEmpAttnUsername.Clear();
            }
            else
            {
                MessageBox.Show("Failed to Delete attendance");
                checkedListBox1.ClearSelected();
                txtEmpAttnUsername.Clear();
            }
        }

        private void btnAttnAdd_Click(object sender, EventArgs e)
        {
            string username = txtEmpAttnUsername.Text;
            string status = "";
            foreach (string s in checkedListBox1.CheckedItems)
            {
                if (s == "Late")
                {
                    status = "late";
                }
                else if (s == "Early Leave")
                {
                    status = "early_leave";
                }
                else if (s == "Absent")
                {
                    status = "absent";
                }
                else if (s == "On Time")
                {
                    status = "ontime";
                }

            }
            if(db.IncrementAttendance(username, status))
            {
                MessageBox.Show("Add attendace successfully");
                checkedListBox1.ClearSelected();
                txtEmpAttnUsername.Clear();
            }
            else
            {
                MessageBox.Show("Failed to add attendance");
                checkedListBox1.ClearSelected();
                txtEmpAttnUsername.Clear();
            }
        }
        private void LoadAttendanceRecords()
        {
            DataTable attendanceTable = db.GetAllAttendance();
            dataGridView1.DataSource = attendanceTable;


        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            LoadAttendanceRecords();
        }
        private void btnAttnShow_Click(object sender, EventArgs e)
        {
            LoadAttendanceRecords();
        }

        private void btnAttnShow_Click_1(object sender, EventArgs e)
        {
            LoadAttendanceRecords();
        }
    }
}
