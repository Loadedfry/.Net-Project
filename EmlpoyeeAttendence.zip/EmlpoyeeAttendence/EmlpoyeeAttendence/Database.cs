﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MySql.Data.MySqlClient;
using Org.BouncyCastle.Asn1.X509;

namespace EmlpoyeeAttendence
{
    public class Database
    {
        private MySqlConnection connection;

        public Database()
        {
            string connectionString = "SERVER=localhost;DATABASE=loginsystem;UID=root;PASSWORD=shipon999;";
            connection = new MySqlConnection(connectionString);
        }

        public bool Login(string username, string password, out string role)
        {
            role = "";
            

            try
            {
                connection.Open();

                // Check in admin table
                string adminQuery = "SELECT * FROM admins WHERE username = @username AND password = @password";
                MySqlCommand adminCmd = new MySqlCommand(adminQuery, connection);
                adminCmd.Parameters.AddWithValue("@username", username);
                adminCmd.Parameters.AddWithValue("@password", password);

                using (MySqlDataReader reader = adminCmd.ExecuteReader())
                {
                    if (reader.Read())
                    {
                        role = "admin";
                        return true;
                    }
                }

                // Check in employee table
                string employeeQuery = "SELECT * FROM employees WHERE username = @username AND password = @password";
                MySqlCommand employeeCmd = new MySqlCommand(employeeQuery, connection);
                employeeCmd.Parameters.AddWithValue("@username", username);
                employeeCmd.Parameters.AddWithValue("@password", password);

                using (MySqlDataReader reader = employeeCmd.ExecuteReader())
                {
                    if (reader.Read())
                    {
                        role = "employee";
                        return true;
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            finally
            {
                connection.Close();
            }

            return false;
        }

        public bool AddEmployee(string username, string password)
        {
            try
            {
                connection.Open();
                string querry = "INSERT INTO emoployees (username, password) VALUES (@username, @password)";
                MySqlCommand cmd = new MySqlCommand(querry, connection);
                cmd.Parameters.AddWithValue("@username", username);
                cmd.Parameters.AddWithValue("@password", password);
                int result = cmd.ExecuteNonQuery();
                return result > 0;

            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                return false;
            }
            finally
            {
                connection.Close();
            }
        }

        public bool DeleteEmployee(String username, string password)
        {
            try
            {
                connection.Open();
                string query = "DELETE FROM employees WHERE username= @username AND password = @password)";
                MySqlCommand cmd = new MySqlCommand(query, connection);
                cmd.Parameters.AddWithValue("@username", username);
                cmd.Parameters.AddWithValue(password, password);
                int result = cmd.ExecuteNonQuery();
                return result > 0;
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                return false;

            }
            finally
            {
                connection.Close();
            }
        }

        public bool IncrementAttendance(String username, string status)
        {
            try
            {
                connection.Open();
                string query = "";
                if (status == "late")
                {
                    query = "UPDATE attendance SET late_days = late_days+ 1 WHERE username = @username";
                }
                else if (status == "early_leave")
                {
                    query = "UPDATE attendance SET early_leave_days = early_leave_days + 1 WHERE username = @username";
                }
                else if (status == "absent")
                {
                    query = "UPDATE attendance SET absentee_days = absentee_days + 1 WHERE username = @username";
                }
                else if (status == "ontime")
                {
                    query = "UPDATE attendance SET OnTime_days = OnTime_days + 1 WHERE username = @username";
                }
                MySqlCommand cmd = new MySqlCommand(query, connection);
                cmd.Parameters.AddWithValue("@username", username);
                int result = cmd.ExecuteNonQuery();
                return result > 0;
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                return false;
            }
            finally
            {
                connection.Close();
            }
        }
        
        public bool DeleteAttendance(String username, String status)
        {
            try
            {
                connection.Open();
                string query = "";
                if (status == "late")
                {
                    query = "UPDATE attendance SET late_days = late_days -1 WHERE username = @username";
                }
                else if (status == "early_leave")
                {
                    query = "UPDATE attendance SET early_leave_days = early_leave_days -1 WHERE username = @username";
                }
                else if (status == "absent")
                {
                    query = "UPDATE attendance SET absentee_days = absentee_days -1 WHERE username = @username";
                }
                else if(status == "ontime")
                {
                    query = "UPDATE attendance SET onTime_days = onTime_days - 1 WHERE username = @username";
                }
                MySqlCommand cmd = new MySqlCommand(query, connection);
                cmd.Parameters.AddWithValue("@username", username);
                int result = cmd.ExecuteNonQuery();
                return result > 0;
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
                return false;
            }
            finally
            {
                connection.Close();
            }
        }

        public DataTable GetAllAttendance()
        {
            DataTable dt = new DataTable();

            try
            {
                connection.Open();
                string query = "SELECT * FROM attendance";
                MySqlCommand cmd = new MySqlCommand(query, connection);
                MySqlDataAdapter adapter = new MySqlDataAdapter(cmd);
                adapter.Fill(dt);
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }
            finally
            {
                connection.Close();
            }
            return dt;
        }
    }
}
